## arucophotoembedding

arucophotoembedding is a python module used to plot one image in another image where the ArUco surrounded.

